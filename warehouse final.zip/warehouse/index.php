<?php 
session_start();
include("webclass.php");
$sc=new WebClass;
?> 
<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="assets/js/color-modes.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.115.4">
    <title>Задание с таблицой</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/sign-in/">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    <link href="jqui/jquery-ui.css" rel="stylesheet">
<script src="js/jquery-3.7.1.js"></script>
<script src="jqui/jquery-ui.js"></script>
<link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
<script>
  $( function() {
    $('#dateChooser').datepicker({dateFormat:'yy-mm-dd'});
  } );
  </script>
 
 </head>
   
<main class=" w-50 m-auto">
<div class="container"> 
 
  <h2>Добавить деталь</h2>
    
   <form action="index.php" method="post" id="add"  class=" w-50 m-auto" >
   <input type="hidden" name="action" value="new_ticket">

  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Наименование детали:</label>
    <input required type="text" class="form-control" name="detail_name" > 
  </div>
  <div class="mb-3">
  <label for="exampleInputEmail1" class="form-label">Дата поступления:</label>
      <input id="dateChooser" name="arrival_date" class="form-control" type="text" value=""/>	
  </div>
  <div class="mb-3 form-check">
    <label for="exampleInputEmail1" class="form-label">Поставщик:</label>
    <?php echo $sc->manufacturer_select();?>
   </div>
  <div class="mb-3 form-check">
    <label for="exampleInputEmail1" class="form-label">Производитель:</label>
    <?php echo $sc->supplier_select();?>
  </div>
  <div class="mb-3 form-check">
    <label for="exampleInputEmail1" class="form-label">Код:</label>
    <input required type="text" class="form-control" name="code" > 
  </div>
  <div class="mb-3 form-check">
    <label for="exampleInputEmail1" class="form-label">Цена:</label>
    <input required type="text" class="form-control" name="price" > 
  </div>
  <div class="mb-3 form-check">
    <label for="exampleInputEmail1" class="form-label">Оператор:</label>
   <?php echo $sc->warehouse_operators_print()?>
  </div>
  <button type="submit" class="btn btn-primary">Добавить</button>
</form>

 <br><br><br>
<h2>Все детали</h2>
	
	<table class="table table-sm table-bordered">
	<thead>
  <th scope="col">#</th>
  <th scope="col">Название детали</th>
  <th scope="col">Дата поставки</th>
  <th scope="col">Поставщик</th>
  <th scope="col">Производитель</th>
  <th scope="col">Код</th>
  <th scope="col">Цена</th>
  <th scope="col">Оператор</th>
	<th>-</th>
	</thead>
	<tbody>
	<?
	$data = $sc->date_select_from_db();

	foreach($data as $i=>$row){
		$bgc="";
		if($row["supplier_id"]==3){
			$bgc="table-success";
		}		
		
		if(!empty($_GET["edit"]) && $_GET["edit"]==$row["id"]){
			
			echo "<tr class=\"$bgc\"><td>$row[id]</td>
      <form action=\"index.php\" method=\"post\">";
			echo "<input type=\"hidden\" name=\"action\" value=\"edit_ticket\">";
			echo "<input type=\"hidden\" name=\"edit_id\" value=\"$row[id]\">";
			echo "<td><input type=\"text\" name=\"name\" value=\"$row[name]\"></td>";
			echo "<td><input type=\"text\" name=\"arrival_date\" value=\"$row[arrival_date]\"></td>";
			echo "<td>".$sc->supplier_data_print($row["supplier_id"])."</td>";
			echo "<td>".$sc->manufacturer_data_print($row["manufacturer_id"])."</td>";
			echo "<td><input type=\"text\" name=\"code\" value=\"$row[code]\"></td>";
			echo "<td><input type=\"text\" name=\"price\" value=\"$row[price]\"></td>";
      echo "<td>".$sc->warehouse_operators_print($row["warehouse_operator_id"])."</td>";
			echo "<td><input type=\"submit\" class=\"btn btn-primary btn-sm\" value=\"Сохранить\"></td>
      </form></tr>";
		}else{
      
			echo "<tr class=\"$bgc\"><td>$row[id]</td>";
			echo "<td>$row[name]</td>";
			echo "<td>$row[arrival_date]</td>";
			echo "<td>$row[supplier_id]</td>";
			echo "<td>$row[manufacturer_id]</td>";
			echo "<td>$row[code]</td>";
			echo "<td>$row[price]</td>";
			echo "<td>$row[warehouse_operator_id]</td>";
 
			echo "<td><a href=\"?edit=$row[id]\" class=\"btn btn-sm btn-dark\">Управление</a></td></tr>";
			
		}
	}
	?>
	</tbody>
	</table>
	

</div>
 
<div id="table">
</div> 
</main>


<script src="assets/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
 
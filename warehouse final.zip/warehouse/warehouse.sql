-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 18, 2023 at 08:37 AM
-- Server version: 5.7.24
-- PHP Version: 8.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `warehouse`
--

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `arrival_date` date DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `manufacturer_id` int(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `warehouse_operator_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`id`, `name`, `arrival_date`, `supplier_id`, `manufacturer_id`, `code`, `price`, `warehouse_operator_id`) VALUES
(1, 'Фильтр масляный', '2022-09-15', 1, 1, 'FM001', '30.00', 1),
(2, 'Тормозные колодки', '2022-09-16', 2, 2, 'TK002', '40.00', 2),
(3, 'Ремень ГРМ', '2022-09-17', 3, 3, 'RG001', '25.00', 3);

-- --------------------------------------------------------

--
-- Table structure for table `manufacturers`
--

CREATE TABLE `manufacturers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `contact_info` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `manufacturers`
--

INSERT INTO `manufacturers` (`id`, `name`, `contact_info`) VALUES
(1, 'ЗАО \"Автодетали-Про\"', 'тел. 789-98-76, email: info@autoprod.com'),
(2, 'ИП Петров Петр Петрович', 'тел. 876-65-43, email: petrov@mail.ru'),
(3, 'ООО \"Технодеталь\"', 'тел. 654-32-10, email: info@techno-det.com');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `contact_info` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `contact_info`) VALUES
(1, 'ООО \"Автозапчасти-М\"', 'тел. 123-45-67, email: info@avtozap.com'),
(2, 'ИП Иванов Иван Иванович', 'тел. 321-54-76, email: ivanov@mail.ru'),
(3, 'ОАО \"Запчасти-Люкс\"', 'тел. 567-78-90, email: info@zaplux.ru');

-- --------------------------------------------------------

--
-- Table structure for table `warehouse_operators`
--

CREATE TABLE `warehouse_operators` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `contact_info` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `warehouse_operators`
--

INSERT INTO `warehouse_operators` (`id`, `name`, `position`, `contact_info`) VALUES
(1, 'Иванов Петр Сергеевич', 'Оператор склада', 'тел. 999-99-99, email: ivanov@warehouse.com'),
(2, 'Смирнова Елена Владимировна', 'Оператор склада', 'тел. 888-88-88, email: smirnova@warehouse.com'),
(3, 'Козлов Андрей Александрович', 'Оператор склада', 'тел. 777-77-77, email: kozlov@warehouse.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `details`
--
ALTER TABLE `details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manufacturers`
--
ALTER TABLE `manufacturers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `warehouse_operators`
--
ALTER TABLE `warehouse_operators`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `details`
--
ALTER TABLE `details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `manufacturers`
--
ALTER TABLE `manufacturers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `warehouse_operators`
--
ALTER TABLE `warehouse_operators`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

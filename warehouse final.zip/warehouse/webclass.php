<?php 
class WebClass{		
	public $connection;

	public function __construct(){		
		$this->connection=mysqli_connect("localhost","root","root","warehouse");
		if(!empty($_POST["action"]) && $_POST["action"]=="edit_ticket"){
			$this->edit_ticket_data($_POST["edit_id"],$_POST['name'],$_POST['arrival_date'],$_POST['supplier_select'],$_POST['manufacturer_select'],$_POST['code'],$_POST['price'],$_POST['warehouse_operator']);
      
		}		
		if(!empty($_POST["action"]) && $_POST["action"]=="new_ticket"){
			print_r($_POST);
			$this->new_ticket_write($_POST['detail_name'],$_POST['arrival_date'],$_POST['supplier_select'],$_POST['manufacturer_select'],$_POST['code'],$_POST['price'],$_POST['warehouse_operator']);
		}	
		
	}	

	public function edit_ticket_data($edit_id,$name,$arrival_date,$supplier_select,$manufacturer_select,$code,$price,$warehouse_operator){		
    $supplier_select=$_POST['supplier_select'];
    $manufacturer_select=$_POST['manufacturer_select'];
  
		mysqli_query($this->connection,"UPDATE `details` SET `name`='$name',`arrival_date`='$arrival_date',`supplier_id`='$supplier_select',`manufacturer_id`='$manufacturer_select',`code`='$code',`price`='$price',`warehouse_operator_id`='$warehouse_operator' WHERE id=$edit_id;");
		
	}	
	public function new_ticket_write($name,$arrival_date,$supplier_select,$manufacturer_select,$code,$price,$warehouse_operator){
		mysqli_query($this->connection,"INSERT INTO `details`( `name`, `arrival_date`, `supplier_id`, `manufacturer_id`, `code`, `price`, `warehouse_operator_id`) VALUES ('$name','$arrival_date','$supplier_select','$manufacturer_select','$code','$price','$warehouse_operator');");
		//$new_id = mysqli_insert_id($this->connection);
		//mysqli_query($this->connection,"INSERT INTO ticket_status_history(ticket_id,status_id) VALUES('$new_id','1')");
	}
	
	
	 
	public function date_select_from_db(){
		$result = mysqli_query($this->connection,"SELECT * FROM `details` ");
		$array=array();
 
		while($row=mysqli_fetch_assoc($result)){
  
			$array[]=array("id"=>$row['id'],"name"=>$row['name'],"arrival_date"=>$row['arrival_date'],"supplier_id"=>$row['supplier_id'],"manufacturer_id"=>$row['manufacturer_id'],"code"=>$row['code'],"price"=>$row['price'],"warehouse_operator_id"=>$row['warehouse_operator_id']);
		}		
		return $array;
	}		
	
	public function manufacturer_data_print($select=NULL){
		$result = mysqli_query($this->connection,"SELECT id,name FROM manufacturers");
		$data="<select name=\"manufacturer_select\">";
		while($row=mysqli_fetch_assoc($result)){
		$s="";
		if(!empty($select) && $select==$row["id"]){
			$s="selected";
		}
		$data.="<option $s value=\"$row[id]\">$row[name]</option>";
		
		}
		$data.="</select>";
		return $data;
	}
	
	public function warehouse_operators_print($select=NULL){
		$result = mysqli_query($this->connection,"SELECT id,name FROM warehouse_operators");
		$data="<select name=\"warehouse_operator\">";
		while($row=mysqli_fetch_assoc($result)){
		$s="";
		if(!empty($select) && $select==$row["id"]){
			$s="selected";
		}
		$data.="<option $s value=\"$row[id]\">$row[name]</option>";
		
		}
		$data.="</select>";
		return $data;
	}
	
	public function supplier_data_print($select=NULL){
		$result = mysqli_query($this->connection,"SELECT id,name FROM suppliers");
		$data="<select name=\"supplier_select\">";
		while($row=mysqli_fetch_assoc($result)){
		$s="";
		if(!empty($select) && $select==$row["id"]){
			$s="selected";
		}
		$data.="<option $s value=\"$row[id]\">$row[name]</option>";
		
		}
		$data.="</select>";
		return $data;
	}
	


	public function manufacturer_select(){
		$result = mysqli_query($this->connection,"SELECT id,name FROM manufacturers");
		$data="<select name=\"manufacturer_select\">";
		while($row=mysqli_fetch_assoc($result)){
		$s="";
		if(!empty($select) && $select==$row["id"]){
			$s="selected";
		}
		$data.="<option $s value=\"$row[id]\">$row[name]</option>";
		
		}
		$data.="</select>";
		return $data;
	}
	
	public function supplier_select(){
		$result = mysqli_query($this->connection,"SELECT id,name FROM suppliers");
		$data="<select name=\"supplier_select\">";
		while($row=mysqli_fetch_assoc($result)){
	 
		$data.="<option value=\"$row[id]\">$row[name]</option>";
		}
		$data.="</select>";
		return $data;
	}
	
 
}
 
 
?>